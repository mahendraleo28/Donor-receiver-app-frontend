import React, { useState } from 'react';
import Hamburger from '../hamburger/Hamburger';
import "./donor.css";
import { useEffect } from 'react';

const DonationForm = () => {
  const [donation, setDonation] = useState({
    donationType: '',
    addressLine1: '',
    addressLine2: '',
    state: '',
    country: '',
    postalCode: '',
  });
  const [donations, setDonations] = useState([]);
  useEffect(() => {
    const fetchDonations = async () => {
      try {
        const response = await fetch('http://localhost:8081/donations/all');
        if (response.ok) {
            console.log("successfull")
          const data = await response.json();
          setDonations(data); // Update state with fetched donation data
        } else {
          console.error('Failed to fetch donation data');
        }
      } catch (error) {
        console.error('Error occurred while fetching donation data:', error);
      }
    };

    fetchDonations();
  }, []);


  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setDonation({ ...donation, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('http://localhost:8081/donations/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(donation),
      });

      if (response.ok) {
        alert('Donation submitted successfully!')
        console.log('Donation submitted successfully!');
        // Reset the form after successful submission if needed
        setDonation({
          donationType: '',
          addressLine1: '',
          addressLine2: '',
          state: '',
          country: '',
          postalCode: '',
        });
      } else {
        alert('Failed to submit donation.')
        console.error('Failed to submit donation.');
      }
    } catch (error) {
      alert('Error occurred while submitting donation:', error)
      console.error('Error occurred while submitting donation:', error);
    }
  };

  return (
    <div>
      <div>
        <Hamburger/>
        </div>
        <br/>
        <br/>
        <br/>
        <br/>
    <form onSubmit={handleSubmit}>
      <label>
        {/* Select Type of donation: */}
        <select
        className='dropdown-for-donor-1st-dropdown'
          name="donationType"
          value={donation.donationType}
          onChange={handleInputChange}
          required
        >
          <option value="">Select Type of donation</option>
          <option value="Clothes">Clothes</option>
          <option value="Food">Food</option>
          <option value="Books">Books</option>
          <option value="Toys">Toys</option>
          <option value="Electronics">Electronics</option>
          <option value="Others">Others</option>
        </select>
      </label>
      <div className='for-input-tags'>
      <input
        type="text"
        name="addressLine1"
        value={donation.addressLine1}
        onChange={handleInputChange}
        placeholder="Address Line 1"
        required
      />
      <input
        type="text"
        name="addressLine2"
        value={donation.addressLine2}
        onChange={handleInputChange}
        placeholder="Address Line 2"
      />
      <input
        type="text"
        name="state"
        value={donation.state}
        onChange={handleInputChange}
        placeholder="State"
        required
      />
      <input
        type="text"
        name="country"
        value={donation.country}
        onChange={handleInputChange}
        placeholder="Country"
        required
      />
      <input
        type="number"
        name="postalCode"
        value={donation.postalCode}
        onChange={handleInputChange}
        placeholder="Postal Code"
        required
      />
      </div>
      <button className='submit-button-in-donor-page' type="submit">Submit Donation</button>
    </form>
    <div>
    <h4 className="donations-in-donor-page">All Donations</h4>
      <table className='table-move-in-donor-page'>
        <thead>
          <tr className="table-header-in-reciever-page">
            <th>ID</th>
            <th>Type</th>
            <th>Address</th>
          </tr>
        </thead>
        <tbody>
          {donations.map((donation) => (
            <tr className="table-data-in-reciever-page" key={donation.id}>
              <td>{donation.id}</td>
              <td>{donation.donationType}</td>
              <td>{`${donation.addressLine1}, ${donation.addressLine2}, ${donation.state}, ${donation.country} - ${donation.postalCode}`}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </div>
  );
};

export default DonationForm;
